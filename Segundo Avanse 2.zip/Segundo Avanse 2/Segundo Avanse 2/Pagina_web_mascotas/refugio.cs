﻿namespace Segundo_Avanse_2.Pagina_web_mascotas
{
    public class refugio
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string CorreoElectronico { get; set; }

    }
}
