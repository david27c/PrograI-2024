﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo_Avanse
{
    public partial class LlenarSolicitud : Form
    {
        public LlenarSolicitud()
        {
            InitializeComponent();
        }

        private void LlenarSolicitud_Load(object sender, EventArgs e)
        {

        }
    }
}
