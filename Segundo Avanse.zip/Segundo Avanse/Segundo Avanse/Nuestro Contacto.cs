﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo_Avanse
{
    public partial class Nuestro_Contacto : Form
    {
        public Nuestro_Contacto()
        {
            InitializeComponent();
        }
    }
}
