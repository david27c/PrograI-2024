﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo_Avanse
{
    public partial class Refugio_Relacionados : Form
    {
        public Refugio_Relacionados()
        {
            InitializeComponent();
        }
    }
}
